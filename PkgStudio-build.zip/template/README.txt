本仓库不分发 Sony SDK 专有文件（orbis-pub-cmd.exe、CONTENTS.zip）。

首次使用前请自行获取并放入本 template 目录（与 README.txt 同级）：
  1. git clone https://github.com/xXxTheDarkprogramerxXx/PS4_Tools.git
  2. 复制 PS4_Tools\TrophyUnlocker\Resources\ 下的 CONTENTS.zip、*.gp4、
     orbis-pub-cmd.exe 到本目录
